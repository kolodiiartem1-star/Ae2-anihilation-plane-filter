package com.example.ae2whitelist;

import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraftforge.common.config.Configuration;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import java.io.File;
import java.util.HashSet;
import java.util.Set;

@Mod(modid = "ae2whitelist", name = "AE2 Annihilation Whitelist", version = "1.0")
public class AE2AnnihilationWhitelist {

    public static Set<Block> whitelist = new HashSet<>();

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File cfgFile = new File(event.getModConfigurationDirectory(), "ae2-annihilation-whitelist.cfg");
        Configuration cfg = new Configuration(cfgFile);
        cfg.load();

        String[] blocks = cfg.getStringList("blocks", "general",
                new String[]{"minecraft:stone","minecraft:dirt","minecraft:sand"},
                "Blocks the annihilation plane is allowed to break");

        for(String s : blocks) {
            Block b = Block.getBlockFromName(s);
            if(b != null) whitelist.add(b);
        }

        cfg.save();
    }

    // Call this instead of AE2 doBreak
    public static void breakBlock(World world, int x, int y, int z) {
        Block b = world.getBlock(x, y, z);
        if (whitelist.contains(b)) {
            world.setBlockToAir(x, y, z);
        }
    }
}